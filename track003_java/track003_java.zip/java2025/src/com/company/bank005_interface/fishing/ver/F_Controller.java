package com.company.bank005_interface.fishing.ver;

import java.util.List;

public interface F_Controller {
	
	  int exec(List<UserInfo> users, int find);
	     
}
