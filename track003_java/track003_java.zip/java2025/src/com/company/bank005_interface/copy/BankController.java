package com.company.bank005_interface.copy;

import java.util.List;

public interface BankController {
	
	public void exec(List<UserInfo> users);



}
