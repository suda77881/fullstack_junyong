package com.company.bank005_interface.copy.copy;

public class Delete implements BankController {
	
	
void exec(UserInfo users) {
		
	}

}
