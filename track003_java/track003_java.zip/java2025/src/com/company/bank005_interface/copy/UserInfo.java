package com.company.bank005_interface.copy;


public class UserInfo {
	
	String Id;
	String Pass;
	double balanace;

}
