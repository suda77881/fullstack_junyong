package com.company.bank005_interface.copy.copy;

public class Login implements BankController {
	
	void exec(UserInfo users){
		
	};

}
