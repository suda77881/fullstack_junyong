package com.company.bank005_interface;

import java.util.List;

public interface BankController {
	
	  int exec(List<UserInfo> users, int find);
	     
}
