package com.company.java008_ex;

public class MethodEx001 {
	public static void dog() {System.out.println("멍멍");} 
	public static void cat() {System.out.println("야옹");}
	public static void line() {System.out.println("========= ");}
	
	public static void main(String[] args) {
		
		dog();
		line();
		cat();
		line();
		
		
	}

}
