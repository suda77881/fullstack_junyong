package com.company.java001;

public class A002 {
	public static void main(String[] args) {
		System.out.println("A");
		System.out.println("AB");
		System.out.println("ABC"); // 여러 줄 사용
		
		// 한 줄로 만드는 방법은?
		System.out.println("A\nAB\nABC"); // 줄 바꿈
		
		// 포맷형식 %s(문자열), %d(정수), 
		System.out.printf("이름 : %s	나이: %d " , "길동" , 12 );
		
	}
}
