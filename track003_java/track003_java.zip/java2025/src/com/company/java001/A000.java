package com.company.java001;	// 1. 부품의 위치

// 주석 , 설명
public class A000 { // 2. 어디에서든지 접근, 부품객체, 부품이름(클래스이름)
  public               static           void main(String[] args) {
// 3. 어디서든지 접근, 바로 사용가능  메모리,    void main(string[] args) 전원 버튼 이름
	     System.out.println("Hello Java");
	  //4.운영체제부품객체. 출력(cmd) , println("하고싶은말") 출력
  	  }
} // end class

// ctrl + f11 ( 실행 )

//