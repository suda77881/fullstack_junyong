package com.company.java001;

public class A001 {
	public static void main(String[] args) {
		System.out.println("Hello");
	} // end main
} // end class

