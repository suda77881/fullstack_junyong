package com.company.java010_ex;

public class ClassArrEx1 {
	public static void main(String[] args) {
		Apple[] apples = new Apple[]
	}

}
