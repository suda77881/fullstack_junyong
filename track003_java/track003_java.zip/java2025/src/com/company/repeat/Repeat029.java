package com.company.repeat;

import java.util.ArrayList;
import java.util.List;

public class Repeat029 {

	public static void main(String[] args) {
			
		
		List<String> colors =  new ArrayList<String>();
		
		colors.add("red");
		colors.add("green");
		colors.add("blue");
		
		System.out.println(colors);

	}

}
