package com.company.repeat;

public class Repeat012_3 {
	
	public static void main(String[] args) {
		
		int i;

		

	   for (i=1; i <= 5 ; i++) {
		   
		   System.out.print(i+" ");
	   }
	   

	   
	   System.out.println("");
	   
	   for (i=5; i >= 1; i--) {
		   
		   System.out.print(i+" ");
	   }
	   

	   
	   System.out.println("");
	   
	   for (i=1; i <= 3; i++) {
		   
		   System.out.print("JAVA" + i + " ");
	   }
	   
	    
	}

}