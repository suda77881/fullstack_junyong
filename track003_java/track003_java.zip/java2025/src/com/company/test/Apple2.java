package com.company.test;

public class Apple2 {

}
