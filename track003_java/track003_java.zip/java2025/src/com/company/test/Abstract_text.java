package com.company.test;


abstract class Count {
	
	protected int num ;
	
	abstract void talk();
	
	
}


class Son extends Count{
	
	@Override public void talk() {};
}






public class Abstract_text {

	public static void main(String[] args) {
		
		
		int []num = {1,2,3,4,5};

	}

}
