package com.company.java001_ex2;

public class A000_ex2 {

	public static void main (String[] args) {
		System.out.println("Hello Java");
	}
}
