package com.company.java010;

public class UserInfo{
	public 		String name;
	protected 	String safeCode;	// 자식
				String house;
	private     int    iQ;
	
	public int getiQ() { return iQ; }
	public void setiQ(int iQ) {  this.iQ = iQ; }
}