package com.company.java005_ex;

public class RepeatEx009 {

	public static void main(String[] args) {

		int hap=0;
		
		// 입력 + 처리
		// ver-1 제일작은단위로 해야할일 - 1이 3의 배수라면 hap누적
		// ver-2 구조				 if(2이 3의 배수라면){hap누적}
		// ver-3 코드작성				  if (3%3==0) {hap+=3;}
		

//		System.out.println(num);

	}

}
