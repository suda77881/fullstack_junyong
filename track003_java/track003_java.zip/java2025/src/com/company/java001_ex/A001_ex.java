package com.company.java001_ex;

public class A001_ex {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
