package com.company.java001_ex;

public class A002_ex {
	public static void main(String[] args) {
		
		// System.out.println("X"); System.out.println("XY"); System.out.println("XYZ");
		 
		System.out.println("X\nXY\nXYZ\n");
		
		System.out.printf("도시 : %s , 인구 : %d " , "인천" , 1000000 );
	
	} 

}
