package com.company.java001_ex; //경로위치

public class A000_ex {// 아무데서나 접근가능 , 부품객체

	public static void main(String[] args) {
			System.out.println("한 번 작성하면 어디서든 실행된다.");
	}
}


//> Q) 패키지명 : com.company.java001_ex 
//> 클래스명 : A000 : A000_ex.java
//> "한 번 작성하면 어디서든 실행된다." 출력