package com.company.java002_ex;

import java.util.Scanner;

public class InputEx2001 {
	public static void main(String[] args) {
		//변수
		double pie;
		Scanner scanner = new Scanner(System.in);
		//입력
		System.out.println("파이값을 입력하시오");
		pie = scanner.nextInt();
		//처리
		//출력
		System.out.println("파이값은 "+ pie +"입니다.");
		
		
	}

}
