package com.company.java002_ex;

public class PrintEx001 {
	public static void main(String[] args) {
		
		// println
		System.out.println("좋아하는 "+ "색상은 " + "RED입니다.");
		
		// print
		System.out.print("좋아하는 색상은 RED입니다.\n"); 
		
		/*
		 *System.out.print("좋아하는 "); System.out.print("색상은 "); System.out.print("RED입니다.\n");
		 */
		
		// printf
		System.out.printf("좋아하는 색상은 %s입니다." , "RED");
	}
}
