package com.company.java002_ex;
import java.util.Scanner;
public class InputEx20222{
	public static void main(String[] args) {
		int kor, eng, mat, total;
		double avg;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("국어점수를 입력하세요:");
		kor = scanner.nextInt();
		System.out.println("영어점수를 입력하세요:");
		
		System.out.println("수학점수를 입력하세요:");
		
	}
}