package com.company.java002_ex;

public class VarEx001 {
	
	public static void main(String[] args) {
		
		int apple;
		
		apple = 1000;
		
		System.out.println("사과가격은 "+apple+"원입니다.");
		
		apple = 2000;
		
		System.out.println("사과가격은 "+apple+"원입니다.");
	}
}
